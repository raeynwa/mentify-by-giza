<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 d-flex justify-content-end align-items-center">
            <div class="p-4 shadow-4 rounded-3">
                <img src="<?php echo e(asset('assets/images/default/last1.png')); ?>" alt="">
            </div>
        </div>
        <div class="col-md-6 d-flex justify-content-start align-items-center">
            <div class="p-4 shadow-4 rounded-3">
                <h2>Cari Kelasmu Di Mentify & Jadi Mentee berikutnya</h2>
                <button type="button" class="btn btn-primary">
                    Cari kelas
                </button>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/macbookpro/Documents/kerja/raey/web/project/giza_lab/test_mentify_by_giza/resources/views/pages/public/component/quotes.blade.php ENDPATH**/ ?>