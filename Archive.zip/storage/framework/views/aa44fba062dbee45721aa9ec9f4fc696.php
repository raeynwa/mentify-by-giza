<nav class="navbar navbar-expand-lg bg-white">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Mentify Bootcamp</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Mentify Lite</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Online Workshop</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Webinar</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /Users/macbookpro/Documents/kerja/raey/web/project/giza_lab/test_mentify_by_giza/resources/views/layouts/second_navbar.blade.php ENDPATH**/ ?>